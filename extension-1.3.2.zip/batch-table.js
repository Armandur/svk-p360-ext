// batch-table.js – Redigerbar tabell med drag-and-drop för massregistrering
// Beror på batch-data.js (BATCH_KOLUMNER, detekteraFilKolumner)

// Tabelldata: array av rad-objekt. Varje rad har textfält + _filer (array av File-objekt per slot)
let batchRader = [];
let synligaKolumner = new Set(['Titel', 'Namn']);
let filKolumner = ['Fil_1']; // Standard: en filkolumn
let dokKontaktKolumner = ['DokKontakt_1']; // Oregistrerad kontakt per slot (override)
let dokTitelKolumner = ['DokTitel_1']; // Överlagring av dokumenttitel per slot
let dokDatumKolumner = ['DokDatum_1']; // Datum per slot (ankomst/skickat/upprättat)

// Referens till slotskonfigurationen (sätts av batch.js) – används för att hämta kategori till OCR
let batchSlotsar = [];
function uppdateraBatchSlotsar(s) { batchSlotsar = s; }

/**
 * Returnerar aktuella rader (för exekvering).
 */
function hämtaBatchRader() {
  sparaFrånTabell();
  return batchRader;
}

/**
 * Sätter antalet filkolumner baserat på slotsar.
 */
function uppdateraFilKolumner(antalSlots) {
  filKolumner = [];
  dokKontaktKolumner = [];
  dokTitelKolumner = [];
  dokDatumKolumner = [];
  for (let i = 1; i <= Math.max(antalSlots, 1); i++) {
    filKolumner.push(`Fil_${i}`);
    dokKontaktKolumner.push(`DokKontakt_${i}`);
    dokTitelKolumner.push(`DokTitel_${i}`);
    dokDatumKolumner.push(`DokDatum_${i}`);
  }
  renderaTabell();
}

/**
 * Lägger till en tom rad i tabellen.
 */
function läggTillRad(data) {
  const rad = { _filer: [] };
  // Initiera alla kända kolumner med tomma värden
  for (const kol of Object.keys(BATCH_KOLUMNER)) {
    rad[kol] = data?.[kol] || '';
  }
  for (const fk of filKolumner) {
    rad[fk] = data?.[fk] || '';
  }
  for (const ck of dokKontaktKolumner) {
    rad[ck] = data?.[ck] || '';
    // Arv-flagga: default true (använd ärendepart); false om explicit kontakt angetts
    const arvKey = `DokKontaktArv_${dokKontaktKolumner.indexOf(ck) + 1}`;
    rad[arvKey] = data?.[arvKey] !== undefined ? data[arvKey] : true;
  }
  for (const dk of dokTitelKolumner) {
    rad[dk] = data?.[dk] || '';
  }
  for (const ddk of dokDatumKolumner) {
    rad[ddk] = data?.[ddk] || '';
  }
  if (data?._filer) rad._filer = data._filer;
  batchRader.push(rad);
  renderaTabell();
  uppdateraStartKnapp();
}

/**
 * Tar bort en rad.
 */
function taBortRad(index) {
  batchRader.splice(index, 1);
  renderaTabell();
  uppdateraStartKnapp();
}

/**
 * Importerar rader från parsad CSV-data.
 * Select-kolumner matchas via value eller etikett (case-insensitive).
 * Kolumner som finns i CSV:en men är dolda slås automatiskt på.
 */
function importeraRader(csvRader) {
  // Auto-visa kolumner som finns i CSV-datan
  for (const [namn, def] of Object.entries(BATCH_KOLUMNER)) {
    if (!def.standard && csvRader.some(r => r[namn])) {
      synligaKolumner.add(namn);
    }
  }
  renderaKolumnTogglar();

  for (const rad of csvRader) {
    const ny = { _filer: [] };
    for (const [kol, def] of Object.entries(BATCH_KOLUMNER)) {
      const v = rad[kol] || '';
      // Select-kolumner: matcha value eller etikett
      if (def.typ === 'select' && v) {
        ny[kol] = matchaSelectVärde(def.alternativNyckel, v);
      } else {
        ny[kol] = v;
      }
    }
    for (const fk of filKolumner) {
      ny[fk] = rad[fk] || '';
    }
    for (let i = 0; i < dokKontaktKolumner.length; i++) {
      const ck = dokKontaktKolumner[i];
      ny[ck] = rad[ck] || '';
      // Arv deriveras från om explicit kontakt finns i CSV; annars default true
      ny[`DokKontaktArv_${i + 1}`] = !ny[ck];
    }
    for (const dk of dokTitelKolumner) {
      ny[dk] = rad[dk] || '';
    }
    for (const ddk of dokDatumKolumner) {
      ny[ddk] = rad[ddk] || '';
    }
    batchRader.push(ny);
  }
  renderaTabell();
  uppdateraStartKnapp();
}

/**
 * Sparar aktuella inmatningsvärden från DOM till batchRader.
 */
function sparaFrånTabell() {
  const kropp = document.getElementById('tabell-kropp');
  if (!kropp) return;
  const trRader = kropp.querySelectorAll('tr');
  trRader.forEach((tr, idx) => {
    if (idx >= batchRader.length) return;
    tr.querySelectorAll('input[data-kol]').forEach(inp => {
      if (inp.type === 'checkbox') {
        batchRader[idx][inp.dataset.kol] = inp.checked;
      } else {
        batchRader[idx][inp.dataset.kol] = inp.value;
      }
    });
    tr.querySelectorAll('select[data-kol]').forEach(sel => {
      batchRader[idx][sel.dataset.kol] = sel.value;
    });
  });
}

/**
 * Aktiverar/avaktiverar synlighet för en valfri kolumn.
 */
function togglaKolumn(kolumnNamn) {
  sparaFrånTabell();
  if (synligaKolumner.has(kolumnNamn)) {
    synligaKolumner.delete(kolumnNamn);
  } else {
    synligaKolumner.add(kolumnNamn);
  }
  renderaKolumnTogglar();
  renderaTabell();
}

/**
 * Renderar kolumntogglarna.
 */
function renderaKolumnTogglar() {
  const container = document.getElementById('kolumn-togglar');
  if (!container) return;
  container.innerHTML = '';
  const valfria = Object.entries(BATCH_KOLUMNER).filter(([, v]) => !v.standard);
  for (const [namn] of valfria) {
    const btn = document.createElement('button');
    btn.textContent = (synligaKolumner.has(namn) ? '✓ ' : '+ ') + namn;
    if (synligaKolumner.has(namn)) btn.classList.add('aktiv');
    btn.addEventListener('click', () => togglaKolumn(namn));
    container.appendChild(btn);
  }
}

/**
 * Renderar hela tabellen.
 */
function renderaTabell() {
  const huvud = document.getElementById('tabell-huvud');
  const kropp = document.getElementById('tabell-kropp');
  if (!huvud || !kropp) return;

  // Bygg kolumnlista: # + synliga standardkolumner + valfria + filkolumner + åtgärd
  const kolumner = [];
  for (const [namn, def] of Object.entries(BATCH_KOLUMNER)) {
    if (def.standard || synligaKolumner.has(namn)) {
      kolumner.push(namn);
    }
  }

  // Header
  huvud.innerHTML = '<th>#</th>';
  for (const kol of kolumner) {
    const th = document.createElement('th');
    const def = BATCH_KOLUMNER[kol];
    th.textContent = def?.visningsnamn || kol;
    huvud.appendChild(th);
  }
  for (let fi = 0; fi < filKolumner.length; fi++) {
    const thKontakt = document.createElement('th');
    thKontakt.textContent = dokKontaktKolumner[fi];
    huvud.appendChild(thKontakt);
    const thTitel = document.createElement('th');
    thTitel.textContent = dokTitelKolumner[fi];
    huvud.appendChild(thTitel);
    const thDatum = document.createElement('th');
    thDatum.textContent = dokDatumKolumner[fi];
    huvud.appendChild(thDatum);
    const thFil = document.createElement('th');
    thFil.textContent = filKolumner[fi];
    huvud.appendChild(thFil);
  }
  huvud.innerHTML += '<th>Status</th><th></th>';

  // Body
  kropp.innerHTML = '';
  batchRader.forEach((rad, idx) => {
    const tr = document.createElement('tr');

    // Radnummer
    tr.innerHTML = `<td class="rad-nr">${idx + 1}</td>`;

    // Fält (text eller select beroende på kolumndefinition)
    for (const kol of kolumner) {
      const td = document.createElement('td');
      const def = BATCH_KOLUMNER[kol];

      if (def?.typ === 'select') {
        const sel = document.createElement('select');
        sel.dataset.kol = kol;
        sel.style.cssText = 'width:100%;border:none;padding:4px;font-size:13px;background:transparent;';

        // Hämta alternativ: fasta eller cachade
        const alternativ = hämtaKolumnAlternativ(def.alternativNyckel);
        const tomOpt = document.createElement('option');
        tomOpt.value = '';
        tomOpt.textContent = '–';
        sel.appendChild(tomOpt);
        for (const alt of alternativ) {
          const opt = document.createElement('option');
          opt.value = alt.value;
          opt.textContent = alt.label;
          sel.appendChild(opt);
        }
        sel.value = rad[kol] || '';
        td.appendChild(sel);
      } else {
        const inp = document.createElement('input');
        inp.type = 'text';
        inp.dataset.kol = kol;
        inp.value = rad[kol] || '';
        td.appendChild(inp);
      }

      tr.appendChild(td);
    }

    // DokKontakt + DokTitel + DokDatum + Fil-celler (per slot)
    for (let fi = 0; fi < filKolumner.length; fi++) {
      // DokKontakt_N – kryssruta (ärendepart) + valfritt textfält
      const ck = dokKontaktKolumner[fi];
      const arvKey = `DokKontaktArv_${fi + 1}`;
      const arvChecked = rad[arvKey] !== false; // default true
      const tdKontakt = document.createElement('td');
      tdKontakt.style.whiteSpace = 'nowrap';

      const arvChk = document.createElement('input');
      arvChk.type = 'checkbox';
      arvChk.dataset.kol = arvKey;
      arvChk.checked = arvChecked;
      arvChk.title = 'Använd ärendepart (Namn) som kontakt för detta ärendedokument';
      arvChk.style.cssText = 'margin-right:4px;vertical-align:middle;cursor:pointer;';

      const kontaktInp = document.createElement('input');
      kontaktInp.type = 'text';
      kontaktInp.dataset.kol = ck;
      kontaktInp.value = rad[ck] || '';
      kontaktInp.placeholder = 'Annan kontakt…';
      kontaktInp.style.cssText = 'width:110px;';
      kontaktInp.disabled = arvChecked;
      if (arvChecked) kontaktInp.placeholder = '(ärendepart)';

      arvChk.addEventListener('change', () => {
        kontaktInp.disabled = arvChk.checked;
        kontaktInp.placeholder = arvChk.checked ? '(ärendepart)' : 'Annan kontakt…';
      });

      tdKontakt.appendChild(arvChk);
      tdKontakt.appendChild(kontaktInp);
      tr.appendChild(tdKontakt);

      // DokTitel_N – textinput för titelöverstyrning
      const dk = dokTitelKolumner[fi];
      const tdTitel = document.createElement('td');
      const titelInp = document.createElement('input');
      titelInp.type = 'text';
      titelInp.dataset.kol = dk;
      titelInp.value = rad[dk] || '';
      titelInp.placeholder = 'Dokumenttitel…';
      tdTitel.appendChild(titelInp);
      tr.appendChild(tdTitel);

      // DokDatum_N – datuminput per slot
      const ddk = dokDatumKolumner[fi];
      const tdDatum = document.createElement('td');
      const datumInp = document.createElement('input');
      datumInp.type = 'text';
      datumInp.dataset.kol = ddk;
      datumInp.value = rad[ddk] || '';
      datumInp.placeholder = 'ÅÅÅÅ-MM-DD';
      datumInp.style.cssText = 'width:95px;';
      tdDatum.appendChild(datumInp);
      tr.appendChild(tdDatum);

      // Fil_N – filväljare
      const fk = filKolumner[fi];
      const td = document.createElement('td');
      td.className = 'fil-cell';
      td.dataset.radIdx = idx;
      td.dataset.filIdx = fi;
      renderaFilCell(td, rad, fi, fk, idx);
      kopplaDragDropCell(td, idx, fi);
      tr.appendChild(td);
    }

    // Status
    const statusTd = document.createElement('td');
    statusTd.innerHTML = `<span class="rad-status väntar" id="rad-status-${idx}">Väntar</span>`;
    tr.appendChild(statusTd);

    // Ta bort
    const taBortTd = document.createElement('td');
    const taBortBtn = document.createElement('button');
    taBortBtn.className = 'ta-bort-rad';
    taBortBtn.textContent = '✕';
    taBortBtn.title = 'Ta bort rad';
    taBortBtn.addEventListener('click', () => { sparaFrånTabell(); taBortRad(idx); });
    taBortTd.appendChild(taBortBtn);
    tr.appendChild(taBortTd);

    kropp.appendChild(tr);
  });
}

/**
 * Renderar innehållet i en fil-cell.
 */
function renderaFilCell(td, rad, filIdx, filKolumn, radIdx) {
  td.innerHTML = '';
  const filObj = rad._filer?.[filIdx];
  const filnamn = filObj ? filObj.name : (rad[filKolumn] || '');

  if (filnamn) {
    const div = document.createElement('div');
    div.className = 'fil-cell-innehåll';
    // Visa varningsikon om filnamn finns men ingen File-objekt (enbart text från CSV)
    const ikon = filObj ? '📄' : '⚠';
    const ikonTitle = filObj ? 'Fil kopplad' : 'Filnamn utan fildata – använd "Koppla filer" för att koppla';
    div.innerHTML = `
      <span title="${ikonTitle}" style="font-size:12px;${filObj ? '' : 'color:#e67e22;cursor:help;'}">${ikon}</span>
      <span class="filnamn" title="${escBatchHtml(filnamn)}">${escBatchHtml(filnamn)}</span>
      <button class="ta-bort-fil" title="Ta bort fil">✕</button>
    `;
    div.querySelector('.ta-bort-fil').addEventListener('click', () => {
      sparaFrånTabell();
      rad[filKolumn] = '';
      if (rad._filer) rad._filer[filIdx] = null;
      renderaTabell();
    });

    // OCR-knapp för PDF-filer med kopplad File-objekt
    if (filObj && (filObj.type === 'application/pdf' || filObj.name.toLowerCase().endsWith('.pdf'))) {
      const ocrBtn = document.createElement('button');
      ocrBtn.className = 'fil-ocr-knapp';
      ocrBtn.textContent = '🔍';
      ocrBtn.title = 'Hämta avsändare/mottagare, datum och titel från PDF (OCR)';
      ocrBtn.style.cssText =
        'margin-left:3px;padding:1px 5px;font-size:11px;cursor:pointer;' +
        'border:1px solid #9ab;border-radius:3px;background:#eef4ff;line-height:1.4;';
      ocrBtn.addEventListener('click', async () => {
        const base64 = await new Promise((resolve, reject) => {
          const reader = new FileReader();
          reader.onload = () => resolve(reader.result);
          reader.onerror = reject;
          reader.readAsDataURL(filObj);
        });
        const kategori = batchSlotsar[filIdx]?.dokumentmall?.kategori || '110';
        await chrome.storage.local.set({
          ocrContext: { typ: 'batch-rad', radIdx, filIdx, kategori, tid: Date.now(),
            befintligÄrendepart: batchRader[radIdx]?.Namn || '' },
          tempOcrFil: base64,
        });
        chrome.tabs.create({
          url: chrome.runtime.getURL(`ocr-kontakt.html?storageKey=tempOcrFil&kategori=${kategori}`),
        });
      });
      div.appendChild(ocrBtn);
    }

    td.appendChild(div);
  } else {
    const btn = document.createElement('button');
    btn.className = 'fil-välj-knapp';
    btn.textContent = '📎';
    btn.title = 'Välj fil';
    btn.addEventListener('click', () => {
      const inp = document.createElement('input');
      inp.type = 'file';
      inp.addEventListener('change', () => {
        if (inp.files[0]) {
          sparaFrånTabell();
          if (!rad._filer) rad._filer = [];
          rad._filer[filIdx] = inp.files[0];
          rad[filKolumn] = inp.files[0].name;
          renderaTabell();
        }
      });
      inp.click();
    });
    td.appendChild(btn);
  }
}

/**
 * Kopplar drag-and-drop till en fil-cell.
 */
function kopplaDragDropCell(td, radIdx, filIdx) {
  td.addEventListener('dragover', (e) => {
    e.preventDefault();
    e.stopPropagation();
    td.classList.add('drag-over');
  });
  td.addEventListener('dragleave', () => {
    td.classList.remove('drag-over');
  });
  td.addEventListener('drop', (e) => {
    e.preventDefault();
    e.stopPropagation();
    td.classList.remove('drag-over');
    const filer = Array.from(e.dataTransfer.files);
    if (filer.length === 0) return;
    sparaFrånTabell();
    if (!batchRader[radIdx]._filer) batchRader[radIdx]._filer = [];
    batchRader[radIdx]._filer[filIdx] = filer[0];
    batchRader[radIdx][filKolumner[filIdx]] = filer[0].name;
    renderaTabell();
  });
}

/**
 * Initierar drag-and-drop på drag-zonen (nya rader).
 */
function initDragZon() {
  const zon = document.getElementById('drag-zon');
  if (!zon) return;

  zon.addEventListener('dragover', (e) => {
    e.preventDefault();
    zon.classList.add('aktiv');
  });
  zon.addEventListener('dragleave', () => {
    zon.classList.remove('aktiv');
  });
  zon.addEventListener('drop', (e) => {
    e.preventDefault();
    zon.classList.remove('aktiv');
    const filer = Array.from(e.dataTransfer.files);
    sparaFrånTabell();
    for (const fil of filer) {
      const rad = { _filer: [fil] };
      for (const kol of Object.keys(BATCH_KOLUMNER)) {
        rad[kol] = '';
      }
      // Föreslå filnamn som titel
      rad.Titel = fil.name.replace(/\.[^.]+$/, '');
      for (const fk of filKolumner) {
        rad[fk] = '';
      }
      for (let i = 0; i < dokKontaktKolumner.length; i++) {
        rad[dokKontaktKolumner[i]] = '';
        rad[`DokKontaktArv_${i + 1}`] = true; // default: använd ärendepart
      }
      for (const dk of dokTitelKolumner) {
        rad[dk] = '';
      }
      for (const ddk of dokDatumKolumner) {
        rad[ddk] = '';
      }
      rad[filKolumner[0]] = fil.name;
      batchRader.push(rad);
    }
    renderaTabell();
    uppdateraStartKnapp();
  });
}

/**
 * Uppdaterar status för en rad i tabellen.
 */
function sättRadStatus(idx, status, text) {
  const el = document.getElementById(`rad-status-${idx}`);
  if (!el) return;
  el.className = `rad-status ${status}`;
  el.textContent = text || status;
}

/**
 * Aktiverar/avaktiverar startknappen baserat på antal rader.
 */
function uppdateraStartKnapp() {
  const harRader = batchRader.length > 0;
  const start = document.getElementById('btn-starta-batch');
  if (start) start.disabled = !harRader;
  const koppla = document.getElementById('btn-koppla-filer');
  if (koppla) koppla.disabled = !harRader;
}

/**
 * Hämtar dropdown-alternativ för en kolumn.
 * Kombinerar fasta (BATCH_FASTA_ALTERNATIV) och cachade (batchCachedAlternativ).
 */
function hämtaKolumnAlternativ(alternativNyckel) {
  if (!alternativNyckel) return [];
  // Fasta alternativ (skyddskoder, statusar, paragrafer)
  if (BATCH_FASTA_ALTERNATIV[alternativNyckel]) {
    return BATCH_FASTA_ALTERNATIV[alternativNyckel];
  }
  // Cachade instansspecifika alternativ (diarieenheter, ansvarigaPersoner)
  if (batchCachedAlternativ[alternativNyckel]) {
    return batchCachedAlternativ[alternativNyckel];
  }
  return [];
}

function escBatchHtml(str) {
  return String(str ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

/**
 * Kopplar valda filer till befintliga rader baserat på filnamn i Fil_N-kolumner.
 * Returnerar { matchade, omatchade } för feedback.
 */
function kopplaFiler(filer) {
  sparaFrånTabell();
  let matchade = 0;
  const omatchade = [];

  for (const fil of filer) {
    let hittad = false;
    for (const rad of batchRader) {
      for (let fi = 0; fi < filKolumner.length; fi++) {
        const filnamn = rad[filKolumner[fi]] || '';
        // Matcha exakt filnamn eller utan sökväg
        if (filnamn && filnamn === fil.name) {
          if (!rad._filer) rad._filer = [];
          rad._filer[fi] = fil;
          matchade++;
          hittad = true;
          break;
        }
      }
      if (hittad) break;
    }
    if (!hittad) omatchade.push(fil.name);
  }

  renderaTabell();
  return { matchade, omatchade };
}

/**
 * Returnerar antal filnamn i tabellen som saknar File-objekt (enbart textnamn).
 */
function räknaOkoppladeFilnamn() {
  let antal = 0;
  for (const rad of batchRader) {
    for (let fi = 0; fi < filKolumner.length; fi++) {
      const filnamn = rad[filKolumner[fi]] || '';
      const filObj = rad._filer?.[fi];
      if (filnamn && !filObj) antal++;
    }
  }
  return antal;
}
